PHOTOBONE — FREE TEST BUILD
===========================

Vibecoded. Just a test. This is an experimental Windows x64 build and may contain bugs. Save copies of your work. Photobone is an independent prototype and is not affiliated with Adobe or Photoshop.

INSTALL
1. Extract the entire Photobone folder from this ZIP.
2. Install the Microsoft .NET 9 Desktop Runtime (Windows x64) if it is not already installed:
   https://dotnet.microsoft.com/en-us/download/dotnet/9.0
3. Install Microsoft Edge WebView2 Runtime if it is not already installed:
   https://developer.microsoft.com/en-us/microsoft-edge/webview2/
4. Start Photobone.exe. Keep the app files together in this folder.

The download is free. The project format and features may change while the test continues.
